const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// API Fibonacci
app.get('/fibonacci', (req, res) => {
    const n = parseInt(req.query.n);
    if (isNaN(n) || n < 1) {
        return res.status(400).json({ error: "Tham số n không hợp lệ" });
    }

    const fib = [];
    for (let i = 0; i < n; i++) {
        if (i === 0) fib.push(0);
        else if (i === 1) fib.push(1);
        else fib.push(fib[i - 1] + fib[i - 2]);
    }

    res.json({ result: fib });
});

app.listen(PORT, () => {
    console.log(`Server đang chạy tại http://localhost:${PORT}`);
});